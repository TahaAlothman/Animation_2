/* For UCRT, positive infinity */
double const _HUGE = __builtin_huge_val();
